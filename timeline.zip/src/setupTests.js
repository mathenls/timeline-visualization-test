// Import jest-dom's custom assertions
import '@testing-library/jest-dom'; 