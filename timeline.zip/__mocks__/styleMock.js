// Style mock for Jest
module.exports = {}; 